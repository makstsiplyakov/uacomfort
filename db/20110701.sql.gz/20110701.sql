-- phpMyAdmin SQL Dump
-- version 3.1.2
-- http://www.phpmyadmin.net
--
-- Хост: 10.0.0.2
-- Время создания: Июл 01 2011 г., 11:14
-- Версия сервера: 5.0.91
-- Версия PHP: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `magent_magenta`
--

-- --------------------------------------------------------

--
-- Структура таблицы `mm_blog_posts`
--

CREATE TABLE `mm_blog_posts` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(30) NOT NULL,
  `autor` varchar(30) NOT NULL,
  `content` text NOT NULL,
  `post_image` varchar(50) NOT NULL,
  `date_time` datetime NOT NULL,
  `last_edit` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=137 ;

--
-- Дамп данных таблицы `mm_blog_posts`
--


-- --------------------------------------------------------

--
-- Структура таблицы `mm_blog_posts_comments`
--

CREATE TABLE `mm_blog_posts_comments` (
  `id` int(11) NOT NULL auto_increment,
  `post_id` int(11) NOT NULL,
  `autor` varchar(30) NOT NULL,
  `autor_email` varchar(30) NOT NULL,
  `content` varchar(250) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=66 ;

--
-- Дамп данных таблицы `mm_blog_posts_comments`
--


-- --------------------------------------------------------

--
-- Структура таблицы `mm_item_images`
--

CREATE TABLE `mm_item_images` (
  `id` int(11) NOT NULL auto_increment,
  `item_id` int(11) NOT NULL,
  `image_link` varchar(128) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `mm_item_images`
--

INSERT INTO `mm_item_images` VALUES(1, 1, 'image1.jpg');
INSERT INTO `mm_item_images` VALUES(2, 1, 'image2.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_item_price_per_day`
--

CREATE TABLE `mm_item_price_per_day` (
  `id` int(11) NOT NULL auto_increment,
  `item_id` int(11) NOT NULL,
  `start_price` float NOT NULL,
  `finish_price` float NOT NULL,
  `money_type` enum('grn','dol','euro') NOT NULL default 'grn',
  `start_period` datetime NOT NULL,
  `end_period` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `mm_item_price_per_day`
--

INSERT INTO `mm_item_price_per_day` VALUES(1, 1, 300, 400, 'grn', '2011-06-05 23:35:19', '2011-06-30 23:35:29');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_item_types`
--

CREATE TABLE `mm_item_types` (
  `id` int(11) NOT NULL auto_increment,
  `type` varchar(128) NOT NULL,
  `comment` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `mm_item_types`
--

INSERT INTO `mm_item_types` VALUES(1, 'квартира', '');
INSERT INTO `mm_item_types` VALUES(2, 'комната', '');
INSERT INTO `mm_item_types` VALUES(3, 'дом', '');
INSERT INTO `mm_item_types` VALUES(4, 'эйлинг', '');
INSERT INTO `mm_item_types` VALUES(5, 'номер', '');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_password_reset`
--

CREATE TABLE `mm_password_reset` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `key` varchar(100) NOT NULL,
  `time_add_key` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='password_reset' AUTO_INCREMENT=22 ;

--
-- Дамп данных таблицы `mm_password_reset`
--

INSERT INTO `mm_password_reset` VALUES(21, 1, 'marseilshavalov@gmail.com', 'dvjnfrjvbrt4356j5i6j5imy55y', '2011-06-29 23:24:30');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_places`
--

CREATE TABLE `mm_places` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(128) NOT NULL,
  `comment` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `mm_places`
--

INSERT INTO `mm_places` VALUES(8, 'Киряловка', '');
INSERT INTO `mm_places` VALUES(7, 'Ялта', '');
INSERT INTO `mm_places` VALUES(6, 'Алушта', '');
INSERT INTO `mm_places` VALUES(9, 'Севастополь', '');
INSERT INTO `mm_places` VALUES(10, 'Бердянск', '');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_users`
--

CREATE TABLE `mm_users` (
  `id` int(11) NOT NULL auto_increment,
  `user_url` varchar(32) NOT NULL,
  `points` int(11) NOT NULL default '0',
  `email` varchar(128) NOT NULL,
  `reg_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL default '0',
  `place_id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `parent_user_id` int(11) NOT NULL default '0',
  `real_visitors_count` int(11) NOT NULL default '0',
  `fake_visitors_count` int(11) NOT NULL default '0',
  `photo_link` varchar(128) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='main user table' AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `mm_users`
--

INSERT INTO `mm_users` VALUES(1, 'название_базы', 10, 'marseilshavalov@gmail.com', '2011-06-29 23:23:54', 1, 2, '55555', 0, 4, 2, 'marseil.jpg', 'Это текст, Который будет размещён на главной странице, типа, базы отдыха. Или там еще какой-то хрени.');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_users_details`
--

CREATE TABLE `mm_users_details` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `phone` varchar(128) NOT NULL,
  `mob_phone` varchar(128) NOT NULL,
  `address` text NOT NULL,
  `reg_IP` varchar(32) NOT NULL,
  `first_name` varchar(64) NOT NULL,
  `last_name` varchar(64) NOT NULL,
  `comment` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='user details table' AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `mm_users_details`
--

INSERT INTO `mm_users_details` VALUES(1, 1, '555-55-555', '067-555-55-55', 'Это адресс, той самой базы (или другой хрени)', '111.111.111.111', 'Марсель', 'Шавалов', 'Всё ок!');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_user_items`
--

CREATE TABLE `mm_user_items` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `item_type` int(11) NOT NULL,
  `image_link` varchar(128) NOT NULL,
  `title` varchar(128) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `mm_user_items`
--

INSERT INTO `mm_user_items` VALUES(1, 1, 5, 'main_thumbnail.jpg', 'Номер №1', 'Это описание номера №1');
INSERT INTO `mm_user_items` VALUES(2, 1, 5, 'main_thumbnail.jpg', 'Номер №1', 'Это описание номера №2');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_user_item_reviews`
--

CREATE TABLE `mm_user_item_reviews` (
  `id` int(11) NOT NULL auto_increment,
  `user_item_id` int(11) NOT NULL,
  `autor` varchar(30) NOT NULL,
  `autor_email` varchar(30) NOT NULL,
  `content` varchar(250) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=48 ;

--
-- Дамп данных таблицы `mm_user_item_reviews`
--

INSERT INTO `mm_user_item_reviews` VALUES(47, 1, 'гость', 'test@test.com', 'Классный номер! ппц!!!', '2011-06-29 23:27:38');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_user_main_page_gallery`
--

CREATE TABLE `mm_user_main_page_gallery` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `image_link` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='user main gallery items' AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `mm_user_main_page_gallery`
--

INSERT INTO `mm_user_main_page_gallery` VALUES(1, 1, 'main_gallery_image.jpg');
INSERT INTO `mm_user_main_page_gallery` VALUES(2, 1, 'main_gallery_image.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_user_reviews`
--

CREATE TABLE `mm_user_reviews` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `autor` varchar(30) NOT NULL,
  `autor_email` varchar(30) NOT NULL,
  `content` varchar(250) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=48 ;

--
-- Дамп данных таблицы `mm_user_reviews`
--

INSERT INTO `mm_user_reviews` VALUES(47, 1, 'Гость2', 'test@test.com', 'Жесткое место!!! Советую всем!', '2011-06-29 23:29:08');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_user_visitors`
--

CREATE TABLE `mm_user_visitors` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `count` time NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='visitors' AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `mm_user_visitors`
--

INSERT INTO `mm_user_visitors` VALUES(1, 1, '2011-06-28', '00:00:14');
INSERT INTO `mm_user_visitors` VALUES(2, 1, '2011-06-29', '00:00:08');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_user_visual_settings`
--

CREATE TABLE `mm_user_visual_settings` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `background_color` varchar(32) NOT NULL,
  `banner_image_link` varchar(128) NOT NULL,
  `text_color` varchar(32) NOT NULL,
  `text_font` varchar(64) NOT NULL,
  `title_color` varchar(32) NOT NULL,
  `title_font` varchar(64) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `mm_user_visual_settings`
--

INSERT INTO `mm_user_visual_settings` VALUES(1, 1, '#FFFFFF', 'banner.jpg', '#000000', 'Arial', '#000000', 'Arial');

-- --------------------------------------------------------

--
-- Структура таблицы `mm_visitors`
--

CREATE TABLE `mm_visitors` (
  `id` int(11) NOT NULL auto_increment,
  `date` date NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `mm_visitors`
--

INSERT INTO `mm_visitors` VALUES(1, '2011-06-28', 1002);
